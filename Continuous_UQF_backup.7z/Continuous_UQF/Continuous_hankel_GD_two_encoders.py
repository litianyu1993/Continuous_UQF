from torch import nn
import torch
import numpy as np
from tensorly import random, tenalg
from torch.nn import functional as F
import tensorly as tl
from Continuous_Hankel_GD import Encoder
from dataset import Dataset
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from matplotlib import pyplot as plt
tl.set_backend('pytorch')
import itertools
def MPS_contraction_single_sample_two_input(mps, x):
    contracted = [tenalg.contract(x[i], [0, 1], mps[i], [1,2]).squeeze() for i in range(x.shape[0])]
    tmp = contracted[0]
    for i in range(1, x.shape[0]):
        tmp = tmp @ contracted[i]
    return tmp.squeeze()

def MPS_contraction_samples(mps, x):
    contracted = [MPS_contraction_single_sample_two_input(mps, data) for data in x]
    return contracted


class Hankel(nn.Module):
    def __init__(self, rank = 5, action_dim = 3, obs_dim = 1, encoded_dim_A = 10, encoder_hidden_A = 10,
                 encoded_dim_O = 10, encoder_hidden_O = 10,
                 output_dim = 1, max_length = 6, seed=0, device='cpu',
                 if_rescale_weights = True, encoder = None):
        super(Hankel, self).__init__()
        self.H = []
        for i in range(max_length):

            dim_0 = rank
            dim_3 = rank
            dim_1 = encoded_dim_A
            dim_2 = encoded_dim_O

            if i == 0:
                dim_0 = 1
            if i == max_length - 1:
                dim_2 = output_dim

            H_tmp = tl.tensor(np.random.rand(dim_0, dim_1, dim_2, dim_3))
            if if_rescale_weights:
                bound = 1. / np.sqrt(dim_0 * dim_1 * dim_2 * dim_3)
                #bound =  1.
                H_tmp = H_tmp * 2 * bound - bound
            for j in range(min(dim_0, dim_2)):
                H_tmp[j, :, :, j] += 1.

            H_tmp = tl.tensor(H_tmp, device=device, requires_grad=True)
            self.H.append(H_tmp)

        # Feature mapping of action observation vector
        if encoder is None:
            self.encoder_A = Encoder(input_dim = action_dim,
                                     encoded_dim = encoded_dim_A, encoder_hidden = encoder_hidden_A,
                                     encoder = None, device = device)
            self.encoder_O = Encoder(input_dim = action_dim,
                                     encoded_dim = encoded_dim_O, encoder_hidden = encoder_hidden_O,
                                     encoder = None, device = device)
            #self.encoder3 = nn.Linear(encoder_hidden, encoded_dim).to(device)
        else:
            self.encoder_A = encoder[0]
            self.encoder_O = encoder[1]
            self.encoder_A.encoder1.weight.requires_grad = False
            self.encoder_A.encoder2.weight.requires_grad = False
            self.encoder_A.encoder1.bias.requires_grad = False
            self.encoder_A.encoder2.bias.requires_grad = False
            self.encoder_O.encoder1.weight.requires_grad = False
            self.encoder_O.encoder2.weight.requires_grad = False
            self.encoder_O.encoder1.bias.requires_grad = False
            self.encoder_O.encoder2.bias.requires_grad = False


    def forward(self, x):
        '''
        :param x: of shape [num_trajectories, length_traj, input_dim]
        :return: forwarded results
        '''
        # Encode the features
        input_shape = x.shape
        x = x.reshape(x.shape[0] * x.shape[1], -1)
        x = tl.tensor(x)
        x = x.float()
        x = self.encoder1(x)
        x = F.relu(x)
        encoded_x = self.encoder2(x)
        encoded_x = F.tanh(encoded_x)

        encoded_x = encoded_x.reshape(input_shape[0], input_shape[1], -1)
        contracted_x = MPS_contraction_samples(self.H, encoded_x)
        return torch.stack(contracted_x)