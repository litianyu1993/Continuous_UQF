import gym
import numpy as np
from gym import error, spaces, utils
from gym.utils import seeding
def sum_to_one(x):
    return x/np.sum(x)
class FooEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, num_states = 5):
        super(FooEnv, self).__init__()
        self.action_space = spaces.Box(low=np.array([-1, -1]), high=np.array([1, 1]), dtype=np.float16)
        self.obs_space = spaces.Box(low=np.array([-1, -1]), high=np.array([1, 1]), dtype=np.float16)
        mu = sum_to_one(np.random.rand(num_states))

        sampled_state = np.random.multinomial(1, mu, size=1)[0]
        for i in range(len(sampled_state)):
            if sampled_state[i] == 1:
                self.current_state = i
        self.num_states = num_states
    def _get_obs(self):
        return np.random.normal(self.current_state, 0.2, 2)
    def _get_reward(self):
        return self.current_state*0.5 + 1
    def _get_action(self):
        return np.random.normal(self.current_state*0.2, 0.2, 2)
    def _transition(self):
        # mu = sum_to_one(np.random.rand(self.num_states))
        # sampled_state = np.random.multinomial(1, mu, size=1)[0]
        # for i in range(len(sampled_state)):
        #     if sampled_state[i] == 1:
        #         self.current_state = i
        if self.current_state +1 < self.num_states:
            self.current_state += 1
        else:
            self.current_state = 0

    def step(self, action):
        obs = self._get_obs()
        self._transition()
        reward = self._get_reward()
        action = self._get_action()
        return obs, reward, False, {}

    def reset(self):
        mu = sum_to_one(np.random.rand(self.num_states))
        sampled_state = np.random.multinomial(1, mu, size=1)[0]
        for i in range(len(sampled_state)):
            if sampled_state[i] == 1:
                self.current_state = i
    def render(self, mode='human', close=False):
        print(self.current_state)

