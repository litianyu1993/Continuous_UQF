import numpy as np

def act_LP(uqf, value_of_his):
    return
