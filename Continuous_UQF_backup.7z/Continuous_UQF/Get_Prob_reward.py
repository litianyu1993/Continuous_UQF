from Getting_traj import get_trajectories, random_agent
import gym
import KDE
import numpy as np
import gym_foo
from sklearn import linear_model
# Specifying hyper-parameters
import sys
def sliding_window(action_obs, rewards, window_size):
    windowed_action_obs = []
    windowed_rewards = []
    assert action_obs.shape[1] == rewards.shape[1]
    for j in range(action_obs.shape[0]):
        for i in range(action_obs.shape[1] - window_size):
            windowed_action_obs.append(action_obs[j, i:i+window_size, :])
            windowed_rewards.append(rewards[j, i+window_size])
    return np.asarray(windowed_action_obs), np.asarray(windowed_rewards)



def contruct_KDE(x):
    '''
    :param env:
    :param num_trajs:
    :param max_episode_length: Max_episode_length/window_size needs to be an integer for now
    :param windwo_size:
    :return:
    '''
    # observation_all, reward_all, action_all = get_trajectories(random_agent, env=env,
    #                                                            num_trajs=num_trajs,
    #                                                            max_episode_length=max_episode_length)
    # action_obs = KDE.combine_obs_action(observation_all, action_all)
    #
    # x, new_rewards = sliding_window(action_obs, reward_all, window_size)
    kde = KDE.Compute_KDE(x.reshape(x.shape[0], -1))
    return kde
def generate_data(env = gym.make('Pendulum-v0'), num_trajs = 1000, max_episode_length = 10, window_size = 5):
    observation_all, reward_all, action_all = get_trajectories(random_agent, env=env,
                                                               num_trajs=num_trajs,
                                                               max_episode_length=max_episode_length)
    'Need to change this in the future for other environments'
    #reward_all += 17 #Make reward positive
    #print(observation_all.shape, action_all.shape)
    action_obs = KDE.combine_obs_action(observation_all, action_all)
    x, new_rewards = sliding_window(action_obs, reward_all, window_size)
    return observation_all, action_all, x, new_rewards


def construct_dataset_PR(kde, x, new_rewards):
    # observation_all, reward_all, action_all = get_trajectories(random_agent, env=env,
    #                                                            num_trajs=num_trajs,
    #                                                            max_episode_length=max_episode_length)
    # action_obs = KDE.combine_obs_action(observation_all, action_all)
    #
    # x, new_rewards = sliding_window(action_obs, reward_all, window_size)
    logprob = np.asarray(KDE.compute_score(kde, x.reshape(x.shape[0], -1)))
    pr = np.multiply(logprob, new_rewards)
    return pr
    #return new_rewards

if __name__ == '__main__':
    env = gym.make('Pendulum-v0')
    'Training the KDE'
    num_trajs = 100
    max_episode_length = 10
    print('Start constructing kde')
    observation_all, action_all, x, new_rewards = generate_data(env=env,
                                                                num_trajs=num_trajs,
                                                                max_episode_length=max_episode_length,
                                                                window_size=5)
    kde = contruct_KDE(x)
    print('Finish constructing kde')

    'Generating PR data'
    num_trajs = 1000
    max_episode_length = 10
    observation_all_pr, action_all_pr, x_pr, new_rewards_pr = generate_data(env=env,
                                                                num_trajs=num_trajs,
                                                                max_episode_length=max_episode_length,
                                                                window_size=5)

    pr = construct_dataset_PR(kde, x_pr, new_rewards_pr)

    regr = linear_model.LinearRegression()

    # Train the model using the training sets
    # print(x_pr.shape)

    pr = np.log(np.abs(pr))
    x_pr = x_pr.reshape(len(x_pr), -1)
    regr.fit(x_pr[:-100], pr[:-100])

    # Make predictions using the testing set
    y_pred = regr.predict(x_pr[-100:])
    print(np.mean((y_pred - pr[-100:])**2))
    print(y_pred[:5])
    print(pr[:5])






















