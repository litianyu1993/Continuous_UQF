from torch import nn
import torch
import numpy as np
from tensorly import random, tenalg
from torch.nn import functional as F
import tensorly as tl
from dataset import Dataset
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from matplotlib import pyplot as plt
tl.set_backend('pytorch')
import itertools

def MPS_contraction(mps, x, return_vec = True):
    '''
    mps: a list of MPS cores (tensorly format), the i-th core is of shape (r_{i-1}, d_i, r_i),
       for the first core r_0 =1, for the last core r_m = 1.
    x: input tensor to be contracted (tensorly format), should be of size (n, d_1, d_2, ..., d_m).
    return: a tensor of shape (n, c_1, c_2, ..., c_m)
    '''
    assert len(mps) == x.ndim - 1, "dimension mismatch between MPO and input tensor x"
    for i in range(len(mps)):
        assert mps[i].shape[1] == x.shape[i+1], str(i)+"th core does not match the input dimension, note the thrid dimension of the mpo core should be the same of the corresponding input tensor dimension"

    output_tmp = tenalg.contract(x, [1], mps[0], [1])
    for i in range(1, x.ndim - 1):
        output_tmp = tenalg.contract(output_tmp, [1, output_tmp.ndim - 1], mps[i], [1, 0])
    return output_tmp.squeeze()

def MPS_contraction_single_sample(mps, x):
    '''
    :param mps:
    :param x: x is of shape [1, traj_length, input_dim]
    :return:
    '''
    #print(x.shape)
    # for i in range(x.shape[0]):
    #     print(i, x.shape, x[i].shape, mps[i].shape)
    contracted = [tenalg.contract(x[i], 0, mps[i], 1).squeeze() for i in range(x.shape[0])]
    tmp = contracted[0]
    for i in range(1, x.shape[0]):
        tmp = tmp @ contracted[i]
        #tmp = F.relu(tmp)
    return tmp.squeeze()

def MPS_contraction_samples(mps, x):
    # for data in x:
    #     print(data.shape)
    # for i in range(len(mps)):
    #     print(mps[i].shape)
    contracted = [MPS_contraction_single_sample(mps, data) for data in x]
    return contracted

class Encoder(nn.Module):
    def __init__(self, input_dim = 4, encoded_dim = 10, encoder_hidden = 10, encoder = None, device = 'cpu'):
        super(Encoder, self).__init__()
        if encoder is None:
            self.encoder1 = nn.Linear(input_dim, encoder_hidden).to(device)
            self.encoder2 = nn.Linear(encoder_hidden, encoded_dim).to(device)
        else:
            self.encoder1 = encoder[0]
            self.encoder2 = encoder[1]
            self.encoder1.weight.requires_grad = False
            self.encoder1.bias.requires_grad = False
            self.encoder2.weight.requires_grad = False
            self.encoder2.bias.requires_grad = False
    def forward(self, x):
        if x.ndim != 2:
            x = x.reshape(x.shape[0] * x.shape[1], -1)
        x = tl.tensor(x)
        x = x.float()
        x = self.encoder1(x)
        x = F.leaky_relu(x)
        encoded_x = self.encoder2(x)
        encoded_x = F.leaky_relu(encoded_x)
        return encoded_x

def sequence_to_tensor(X):
    '''
    Transforming X from numpy array mode to tensor mode
    :param X: Input data, should be of the dimension of n*l*d_x
    :return: Tensor form of the input data X
    '''
    news_shape = [X.shape[0]]
    for i in range(X.shape[1]):
        news_shape.append(X.shape[2])
    news = torch.ones(news_shape)
    for i in range(X.shape[0]):
        temp = X[i][0]
        for j in range(1, X.shape[1]):
            temp = torch.tensordot(temp, X[i][j], dims=0)
        news[i] = temp
        #print(temp.shape)
    return news
def get_bound(w):
    size = 1.
    for i in range(len(w.shape)):
        size *= w.shape[i]
    return 1. / np.sqrt(size)
class CWFA(nn.Module):
    def __init__(self, rank=5, input_dim=4, encoded_dim=10, encoder_hidden=10,
                 output_dim=1, device='cpu', encoder=None):
        super(CWFA, self).__init__()
        self.alpha = tl.tensor(np.random.rand(1, rank))
        self.alpha = self.alpha * 2 * get_bound(self.alpha) - get_bound(self.alpha)
        self.A = tl.tensor(np.random.rand(rank, encoded_dim, rank))
        self.A = self.A * 2 * get_bound(self.A) - get_bound(self.A)
        for i in range(rank):
            self.A[i, :, i] += 1.
        self.omega = tl.tensor(np.random.rand(rank, output_dim))
        self.omega = self.omega * 2 * get_bound(self.omega) - get_bound(self.omega)

        if encoder is None:
            self.encoder1 = nn.Linear(input_dim, encoder_hidden).to(device)
            self.encoder2 = nn.Linear(encoder_hidden, encoded_dim).to(device)
            #self.encoder3 = nn.Linear(encoder_hidden, encoded_dim).to(device)
        else:
            self.encoder1 = encoder[0]
            self.encoder2 = encoder[1]
            self.encoder1.weight.requires_grad = False
            self.encoder1.bias.requires_grad = False
            self.encoder2.weight.requires_grad = False
            self.encoder2.bias.requires_grad = False
    def forward(self, x):
        '''
        :param x: of shape [num_trajectories, length_traj, input_dim]
        :return: forwarded results
        '''
        # Encode the features
        input_shape = x.shape
        x = x.reshape(x.shape[0] * x.shape[1], -1)
        x = tl.tensor(x)
        x = x.float()
        x = self.encoder1(x)
        x = F.relu(x)
        encoded_x = self.encoder2(x)
        encoded_x = F.tanh(encoded_x)

        encoded_x = encoded_x.reshape(input_shape[0], input_shape[1], -1)
        mps = [tl.tenalg.contract(self.alpha, 1, self.A, 0)]
        for i in range(1, input_shape[1]-1):
            mps.append(self.A)
        mps.append(tl.tenalg.contract(self.A, 2, self.omega, 0))

        contracted_x = MPS_contraction_samples(mps, encoded_x)
        return torch.stack(contracted_x)

class Hankel(nn.Module):
    def __init__(self, rank = 5, input_dim = 4, encoded_dim = 10, encoder_hidden = 10,
                 output_dim = 1, max_length = 6, seed=0, device='cpu', if_rescale_weights = True, encoder = None):
        super(Hankel, self).__init__()
        self.H = []
        for i in range(max_length):

            dim_0 = rank
            dim_2 = rank
            dim_1 = encoded_dim

            if i == 0:
                dim_0 = 1
            if i == max_length - 1:
                dim_2 = output_dim

            H_tmp = tl.tensor(np.random.rand(dim_0, dim_1, dim_2))
            if if_rescale_weights:
                bound = 1. / np.sqrt(dim_0 * dim_1 * dim_2)
                #bound =  1.
                H_tmp = H_tmp * 2 * bound - bound
            for j in range(min(dim_0, dim_2)):
                H_tmp[j, :, j] += 1.

            H_tmp = tl.tensor(H_tmp, device=device, requires_grad=True)
            self.H.append(H_tmp)

        # Feature mapping of action observation vector
        if encoder is None:
            self.encoder1 = nn.Linear(input_dim, encoder_hidden).to(device)
            self.encoder2 = nn.Linear(encoder_hidden, encoded_dim).to(device)
            #self.encoder3 = nn.Linear(encoder_hidden, encoded_dim).to(device)
        else:
            self.encoder1 = encoder[0]
            self.encoder2 = encoder[1]
            self.encoder1.weight.requires_grad = False
            self.encoder1.bias.requires_grad = False
            self.encoder2.weight.requires_grad = False
            self.encoder2.bias.requires_grad = False
        # for i in range(len(self.H)):
        #     print('init', self.H[i].shape)
        # Some class properties that might come handy
        self.output_dim = output_dim
        self.input_dim = input_dim
        self.device = device
        self.encoded_dim = encoded_dim


    def forward(self, x):
        '''
        :param x: of shape [num_trajectories, length_traj, input_dim]
        :return: forwarded results
        '''
        # Encode the features
        input_shape = x.shape
        x = x.reshape(x.shape[0] * x.shape[1], -1)
        x = tl.tensor(x)
        x = x.float()
        x = self.encoder1(x)
        x = F.relu(x)
        encoded_x = self.encoder2(x)
        encoded_x = F.tanh(encoded_x)

        # encoded_x = self.encoder3(encoded_x)
        # encoded_x = F.softmax(encoded_x)



        #encoded_x = x
        # Now x is of shape [n * length_traj, input_dim]
        # encoded_x = encoded_x.reshape(input_shape[0], input_shape[1], -1)
        # Now x is of shape [n, length_traj, input_dim]
        # ones = tl.tensor(np.ones((encoded_x.shape[0], encoded_x.shape[1], 1)))
        # encoded_x = torch.cat((encoded_x, ones), dim = 2)
        # for i in range(len(self.H)):
        #     print(i, self.H[i].shape)

        encoded_x = encoded_x.reshape(input_shape[0], input_shape[1], -1)
        contracted_x = MPS_contraction_samples(self.H, encoded_x)

        # encoded_x = sequence_to_tensor(encoded_x)
        # #print(encoded_x.shape)
        # contracted_x = MPS_contraction(self.H, encoded_x)

        #contracted_x = [MPS_contraction_single_sample(self.H, e_x) for e_x in encoded_x]
        #return contracted_x
        return torch.stack(contracted_x)


# The train and test function of the Tensorized Network
def train(model, device, train_loader, optimizer, epoch):
    model.train()
    error = []
    #optimizer.zero_grad()
    with torch.no_grad():
        if epoch % 50 == 0:
            print('here')
            for i in range(len(model.H)):
                dim_0 = model.H[i].shape[0]
                dim_2 = model.H[i].shape[2]
                for j in range(min(dim_0, dim_2)):
                    model.H[i][j, :, j] = 1.
    for batch_idx, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        optimizer.zero_grad()
        output = model(data).to(device)
        #loss = F.mse_loss(torch.log(torch.abs(output)), torch.log(torch.abs(target)))
        loss = F.mse_loss(output, target)
        loss.backward()
        optimizer.step()
        error.append(loss.item())
    print(output[:5], target[:5])
    print('\nTrain Epoch: ' + str(epoch) + ' Training Loss: ' + str(sum(error) / len(error)))
    return sum(error) / len(error)


def test(model, device, test_loader):
    model.eval()
    test_loss = 0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data).to(device)
            loss = F.mse_loss(output, target)
            #loss = F.mse_loss(torch.log(torch.abs(output)), torch.log(torch.abs(target)))
            test_loss += loss.item()  # sum up batch loss
            # pred = output.argmax(dim=1, keepdim=True)  # get the index of the max log-probability
            # correct += pred.eq(target.view_as(pred)).sum().item()

    test_loss /= len(test_loader)

    print('Test set: Average loss: {:.4f}'.format(
        test_loss))
    return test_loss

def Training_process(hankel, training_generator, validation_generator, lr, step_size, gamma, epochs, device = 'cpu'):
    params = [hankel.encoder1.bias, hankel.encoder1.weight,
                            hankel.encoder2.bias, hankel.encoder2.weight]
    for i in range(len(hankel.H)):
        params.append(hankel.H[i])



    optimizer = optim.Adam(params, lr=lr, amsgrad  = True)
    #for i in range(len(hankel.H)):
    #    print('train hankel', hankel.H[i].shape)
    # scheduler for automatic decaying the learning rate
    scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma)

    train_loss_tt = []
    vali_loss_tt = []

    # # Training
    for epoch in range(1, epochs + 1):
        train_loss_tt.append(train(hankel, device, training_generator, optimizer, epoch))
        vali_loss_tt.append(test(hankel, device, validation_generator))
        scheduler.step()
    return hankel, train_loss_tt, vali_loss_tt

def train_CWFA(cwfa, training_generator, validation_generator, lr, step_size, gamma, epochs, device = 'cpu'):
    params = [cwfa.encoder1.bias, cwfa.encoder1.weight,
              cwfa.encoder2.bias, cwfa.encoder2.weight,
              cwfa.alpha, cwfa.A, cwfa.omega]
    optimizer = optim.Adam(params, lr=lr, amsgrad=True)
    scheduler = StepLR(optimizer, step_size=step_size, gamma=gamma)

    train_loss_tt = []
    vali_loss_tt = []
    for epoch in range(1, epochs + 1):
        train_loss_tt.append(train(cwfa, device, training_generator, optimizer, epoch))
        vali_loss_tt.append(test(cwfa, device, validation_generator))
        scheduler.step()
    return hankel, train_loss_tt, vali_loss_tt

if __name__ == '__main__':
    device = 'cpu'
    hankel = Hankel(rank = 5, input_dim = 4, encoded_dim = 10, encoder_hidden = 10,
                 output_dim = 2, max_length = 6, seed=0, device=device, if_rescale_weights= False)
    np.random.seed(0)


    # Parameters
    generator_params = {'batch_size': 512,
              'shuffle': True,
              'num_workers': 0}
    lr = 0.01
    step_size = 100
    gamma = 1
    epochs = 500

    x = np.random.rand(2000, 6, 4)
    y = hankel(x)
    #y = tl.tensor(x[:, :2, 0]).float()
    #y = tl.tensor(np.ones(y.shape)).float()
    training = Dataset(data=[x, y])

    # Generators

    training_generator = torch.utils.data.DataLoader(training, **generator_params)

    x = np.random.rand(1000, 6, 4)
    y = hankel(x)
    validation = Dataset(data=[x, y])
    validation_generator = torch.utils.data.DataLoader(validation, **generator_params)

    hankel = Hankel(rank=5, input_dim=4, encoded_dim=10, encoder_hidden=10,
                    output_dim=2, max_length=6, seed=0, device=device, if_rescale_weights=True)

    hankel, train_error, vali_error = Training_process(hankel = hankel, training_generator = training_generator
                                                       , validation_generator = validation_generator,
                                                       lr = lr, step_size = step_size, gamma = gamma, epochs = epochs)
    print(hankel(x[:5]))
    print(y[:5])
    plt.plot(train_error)
    plt.plot(vali_error)
    plt.show()


