from LinRNN import LinRNN
import numpy as np
import tensorly as tl
from tensorly import tenalg
from Continuous_Hankel_GD import Encoder
tl.set_backend('pytorch')
def Monte_carlo_integral(encoder, value_range, input_dim, num_samples = 100000):

    x = np.random.uniform(value_range[0], value_range[1], (num_samples, input_dim))
    #print(encoder(x).shape)
    accum = np.sum(encoder(x).detach().numpy(), axis = 0)

    measure = value_range[1] - value_range[0]
    return measure * accum / float(num_samples)

def convert_WFA_prefix(wfa, encoder, input_dim, value_range, samples_for_MC = 100000):
    inte = Monte_carlo_integral(encoder, value_range, input_dim, num_samples = samples_for_MC).reshape(1, -1)
    A = wfa.A
    A_s = tl.to_numpy(tenalg.contract(tl.tensor(inte), [1], tl.tensor(A), [1]))
    rank = A.shape[0]
    wfa.Omega = np.linalg.pinv(np.eye(rank) - A_s) @ wfa.Omega
    return wfa

if __name__ == '__main__':

    rank = 5
    input_dim = 3
    output_dim = 1
    alpha = np.random.rand(rank)
    A = np.random.rand(rank, input_dim, rank)
    Omega = np.random.rand(rank)
    wfa = LinRNN(alpha, A, Omega)
    print(wfa.Omega)
    encoder = Encoder(input_dim = input_dim, encoded_dim = 3, encoder_hidden = 10)

    wfa_p = convert_WFA_prefix(wfa, encoder = encoder, input_dim = input_dim, value_range = [0, 1], samples_for_MC=100000)
    print(wfa_p.Omega)
