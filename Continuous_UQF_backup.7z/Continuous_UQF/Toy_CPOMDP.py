import numpy as np

def sum_to_one(x):
    return x/np.sum(x)



class CPOMDP():
    def __init__(self, num_states = 5, obs_dim = 3, action_dim = 1):
        mu = sum_to_one(np.random.rand(num_states))
